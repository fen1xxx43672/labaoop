#pragma once

#include "Stand.h"

namespace TechInspection {

	public ref class Inspector {
	private:
		String^ name;
		array<Stand^>^ stands;
		double         exitX;
		int            passedCount;
		int            failedCount;

	public:
		Inspector(String^ name, array<Stand^>^ stands, double exitX) {
			this->name = name;
			this->stands = stands;
			this->exitX = exitX;
			this->passedCount = 0;
			this->failedCount = 0;
			for each (Stand ^ s in this->stands)
				s->CheckCompleted += gcnew StandResultHandler(this, &Inspector::OnCheckCompleted);
		}

		property String^ Name { String^ get() { return name; } }
		property int     PassedCount { int get() { return passedCount; } }
		property int     FailedCount { int get() { return failedCount; } }
		property int     ProcessedCount { int get() { return passedCount + failedCount; } }

		event EventHandler^ StatisticsChanged;

		void OnCarArrived(Car^ car, int standIndex) {
			stands[standIndex]->StartCheck(car);
		}

		void OnCheckCompleted(Stand^ stand, Car^ car, bool passed) {
			car->RecordResult(passed);
			if (!passed) {
				failedCount++;
				car->Finish(false, exitX);
				RaiseStats();
			}
			else if (stand->Index == stands->Length - 1) {
				passedCount++;
				car->Finish(true, exitX);
				RaiseStats();
			}
			else {
				Stand^ next = stands[stand->Index + 1];
				car->GoToStand(next->X, next->Index);
			}
		}

	private:
		void RaiseStats() {
			StatisticsChanged(this, EventArgs::Empty);
		}
	};

}