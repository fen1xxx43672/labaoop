#pragma once

#include "Car.h"

namespace TechInspection {

	ref class Stand;

	public delegate void StandCarHandler(Stand^ stand, Car^ car);
	public delegate void StandResultHandler(Stand^ stand, Car^ car, bool passed);

	public ref class Stand {
	private:
		String^ name;
		int     index;
		double  x;
		bool    busy;
		Car^ car;
		double  progress;
		double  duration;
		double  failChance;
		int     checksDone;
		Random^ rnd;

	public:
		Stand(String^ name, int index, double x, double failChance) {
			this->name = name;
			this->index = index;
			this->x = x;
			this->failChance = failChance;
			this->busy = false;
			this->car = nullptr;
			this->progress = 0;
			this->duration = 2.5;
			this->checksDone = 0;
			this->rnd = gcnew Random(Environment::TickCount + index * 7919);
		}

		property String^ Name { String^ get() { return name; } }
		property int     Index { int get() { return index; } }
		property double  X { double get() { return x; } }
		property bool    IsBusy { bool get() { return busy; } }
		property double  Progress { double get() { return progress; } }
		property Car^ CurrentCar { Car^ get() { return car; } }
		property int     ChecksDone { int get() { return checksDone; } }
		property double  FailChance {
			double get() { return failChance; }
			void set(double value) {
				if (value < 0) value = 0;
				if (value > 1) value = 1;
				failChance = value;
			}
		}

		event StandCarHandler^ CheckStarted;
		event StandResultHandler^ CheckCompleted;

		void StartCheck(Car^ c) {
			if (busy) return;
			car = c;
			busy = true;
			progress = 0;
			CheckStarted(this, c);
		}

		void Update(double dt) {
			if (!busy) return;
			progress += dt / duration;
			if (progress >= 1.0) {
				Car^ c = car;
				double p = failChance + c->Mileage / 2000000.0;
				if (p > 0.95) p = 0.95;
				bool ok = rnd->NextDouble() >= p;

				busy = false;
				car = nullptr;
				progress = 0;
				checksDone++;
				CheckCompleted(this, c, ok);
			}
		}
	};

}