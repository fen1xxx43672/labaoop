#pragma once

using namespace System;
using namespace System::Drawing;

namespace TechInspection {

	enum class CarState { Driving, Checking, Passed, Failed };

	ref class Car;

	public delegate void CarHandler(Car^ car);
	public delegate void CarStandHandler(Car^ car, int standIndex);
	public delegate void CarResultHandler(Car^ car, bool passed);

	public ref class Car {
	private:
		String^ number;
		Color    bodyColor;
		int      mileage;
		double   speed;
		double   x;
		double   targetX;
		int      targetStand;
		CarState state;
		int      checksPassed;

	public:
		Car(String^ number, Color bodyColor, int mileage, double speed, double startX) {
			this->number = number;
			this->bodyColor = bodyColor;
			this->mileage = mileage < 0 ? 0 : mileage;
			this->speed = speed;
			this->x = startX;
			this->targetX = startX;
			this->targetStand = -1;
			this->state = CarState::Driving;
			this->checksPassed = 0;
		}

		property String^ Number { String^ get() { return number; } }
		property Color   BodyColor { Color get() { return bodyColor; } }
		property double  X { double get() { return x; } }
		property CarState State { CarState get() { return state; } }
		property int     ChecksPassed { int get() { return checksPassed; } }

		property int Mileage {
			int get() { return mileage; }
			void set(int value) { mileage = value < 0 ? 0 : value; }
		}
		property double Speed {
			double get() { return speed; }
			void set(double value) {
				if (value < 20.0) value = 20.0;
				if (value > 400.0) value = 400.0;
				speed = value;
			}
		}

		event CarStandHandler^ ArrivedAtStand;
		event CarResultHandler^ InspectionFinished;
		event CarHandler^ LeftStation;

		void GoToStand(double standX, int standIndex) {
			targetX = standX;
			targetStand = standIndex;
			state = CarState::Driving;
		}

		void RecordResult(bool ok) {
			if (ok) checksPassed++;
		}

		void Finish(bool passed, double exitX) {
			state = passed ? CarState::Passed : CarState::Failed;
			targetX = exitX;
			targetStand = -1;
			InspectionFinished(this, passed);
		}

		void Move(double dt, double limitX) {
			if (state == CarState::Checking) return;

			double dest = Math::Min(targetX, limitX);
			if (dest > x)
				x = Math::Min(dest, x + speed * dt);

			if (x >= targetX - 0.01) {
				x = targetX;
				if (targetStand >= 0) {
					state = CarState::Checking;
					ArrivedAtStand(this, targetStand);
				}
				else {
					LeftStation(this);
				}
			}
		}
	};

}