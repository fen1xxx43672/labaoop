﻿#pragma once

#include "Car.h"
#include "Stand.h"
#include "Inspector.h"

namespace CppCLRWinFormsProject {

	using namespace System;
	using namespace System::Collections::Generic;
	using namespace System::ComponentModel;
	using namespace System::Drawing;
	using namespace System::Drawing::Drawing2D;
	using namespace System::Windows::Forms;
	using namespace TechInspection;

	public ref class ScenePanel : public Panel {
	public:
		ScenePanel() {
			this->DoubleBuffered = true;
			this->ResizeRedraw = true;
		}
	};

	public ref class Form1 : public System::Windows::Forms::Form
	{
	private:
		literal int CarLength = 100;
		literal int Gap = 14;
		literal double SpawnX = -100.0;
		literal double ExitX = 1200.0;

		System::Windows::Forms::Timer^ timer;
		ScenePanel^ scene;
		Panel^ pnlTop;
		Panel^ pnlBottom;
		Button^ btnAdd;
		Button^ btnPause;
		CheckBox^ chkAuto;
		TrackBar^ trkSpeed;
		ComboBox^ cmbFail;
		NumericUpDown^ nudMileage;
		Label^ lblSpd;
		Label^ lblStats;
		ListBox^ lstLog;

		List<Car^>^ cars;
		List<Car^>^ toRemove;
		array<Stand^>^ stands;
		Inspector^ inspector;
		Random^ rnd;
		double simTime;
		double autoTimer;
		int pending;

		System::Drawing::Font^ fontTitle;
		System::Drawing::Font^ fontBold;
		System::Drawing::Font^ fontSmall;
		StringFormat^ fmtCenter;

	public:
		Form1(void)
		{
			rnd = gcnew Random();
			cars = gcnew List<Car^>();
			toRemove = gcnew List<Car^>();
			simTime = 0; autoTimer = 0; pending = 0;

			fontTitle = gcnew System::Drawing::Font(L"Segoe UI", 12.0f, FontStyle::Bold);
			fontBold = gcnew System::Drawing::Font(L"Segoe UI", 9.5f, FontStyle::Bold);
			fontSmall = gcnew System::Drawing::Font(L"Segoe UI", 8.5f);
			fmtCenter = gcnew StringFormat();
			fmtCenter->Alignment = StringAlignment::Center;
			fmtCenter->LineAlignment = StringAlignment::Center;

			BuildUI();
			BuildModel();
			UpdateStats();
			Log(L"Станция готова к работе");

			timer = gcnew System::Windows::Forms::Timer();
			timer->Interval = 30;
			timer->Tick += gcnew EventHandler(this, &Form1::OnTick);
			timer->Start();
		}

	private:
		Label^ MakeLabel(String^ text, int x, int y, int w) {
			Label^ l = gcnew Label();
			l->Text = text;
			l->SetBounds(x, y, w, 22);
			l->AutoSize = false;
			l->TextAlign = ContentAlignment::MiddleLeft;
			return l;
		}

		void BuildUI() {
			this->Text = L"Моделирование прохождения техосмотра";
			this->StartPosition = FormStartPosition::CenterScreen;
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->ClientSize = System::Drawing::Size(1100, 620);

			pnlTop = gcnew Panel();
			pnlTop->Dock = DockStyle::Top;
			pnlTop->Height = 80;
			pnlTop->BackColor = Color::FromArgb(240, 240, 240);

			btnAdd = gcnew Button();
			btnAdd->Text = L"Добавить автомобиль";
			btnAdd->SetBounds(10, 8, 170, 30);
			btnAdd->Click += gcnew EventHandler(this, &Form1::OnAddClick);

			Label^ lblMil = MakeLabel(L"Пробег, тыс. км (0 – случайно):", 190, 12, 215);
			nudMileage = gcnew NumericUpDown();
			nudMileage->Minimum = 0;
			nudMileage->Maximum = 500;
			nudMileage->Value = 0;
			nudMileage->SetBounds(408, 10, 70, 24);

			Label^ lblFail = MakeLabel(L"Вероятность брака на стенде:", 495, 12, 185);
			cmbFail = gcnew ComboBox();
			cmbFail->DropDownStyle = ComboBoxStyle::DropDownList;
			cmbFail->Items->AddRange(gcnew array<Object^>{ L"5%", L"10%", L"20%", L"35%" });
			cmbFail->SelectedIndex = 1;
			cmbFail->SetBounds(684, 10, 70, 24);
			cmbFail->SelectedIndexChanged += gcnew EventHandler(this, &Form1::OnFailChanged);

			chkAuto = gcnew CheckBox();
			chkAuto->Text = L"Автопоявление авто";
			chkAuto->SetBounds(775, 12, 160, 22);

			btnPause = gcnew Button();
			btnPause->Text = L"Пауза";
			btnPause->SetBounds(950, 8, 130, 30);
			btnPause->Click += gcnew EventHandler(this, &Form1::OnPauseClick);

			lblSpd = MakeLabel(L"Скорость моделирования: ×1,0", 10, 48, 235);
			trkSpeed = gcnew TrackBar();
			trkSpeed->Minimum = 1;
			trkSpeed->Maximum = 10;
			trkSpeed->Value = 2;
			trkSpeed->TickFrequency = 1;
			trkSpeed->SetBounds(245, 40, 200, 35);
			trkSpeed->ValueChanged += gcnew EventHandler(this, &Form1::OnSpeedChanged);

			lblStats = MakeLabel(L"", 460, 48, 630);
			lblStats->Font = fontBold;

			pnlTop->Controls->AddRange(gcnew array<Control^>{
				btnAdd, lblMil, nudMileage, lblFail, cmbFail, chkAuto, btnPause, lblSpd, trkSpeed, lblStats });

			pnlBottom = gcnew Panel();
			pnlBottom->Dock = DockStyle::Bottom;
			pnlBottom->Height = 130;
			lstLog = gcnew ListBox();
			lstLog->Dock = DockStyle::Fill;
			lstLog->IntegralHeight = false;
			lstLog->HorizontalScrollbar = true;
			lstLog->Font = gcnew System::Drawing::Font(L"Consolas", 9.0f);
			pnlBottom->Controls->Add(lstLog);

			scene = gcnew ScenePanel();
			scene->Dock = DockStyle::Fill;
			scene->Paint += gcnew PaintEventHandler(this, &Form1::OnScenePaint);

			this->Controls->Add(scene);
			this->Controls->Add(pnlBottom);
			this->Controls->Add(pnlTop);
		}

		void BuildModel() {
			stands = gcnew array<Stand^>(4);
			array<String^>^ names = gcnew array<String^>{
				L"Тормоза", L"Свет фар", L"Развал-схождение", L"Выхлоп" };

			for (int i = 0; i < 4; i++) {
				stands[i] = gcnew Stand(names[i], i, 260.0 + i * 210.0, 0.10);
				stands[i]->CheckStarted += gcnew StandCarHandler(this, &Form1::OnCheckStarted);
				stands[i]->CheckCompleted += gcnew StandResultHandler(this, &Form1::OnCheckCompleted);
			}

			inspector = gcnew Inspector(L"Иванов И. И.", stands, ExitX);
			inspector->StatisticsChanged += gcnew EventHandler(this, &Form1::OnStatsChanged);
		}

		void SpawnCar() {
			array<String^>^ letters = gcnew array<String^>{
				L"А", L"В", L"Е", L"К", L"М", L"Н", L"О", L"Р", L"С", L"Т", L"У", L"Х" };
			array<Color>^ palette = gcnew array<Color>{
				Color::Crimson, Color::SteelBlue, Color::Goldenrod, Color::SeaGreen,
					Color::DarkOrchid, Color::Silver, Color::Tomato, Color::RoyalBlue };

			String^ plate = letters[rnd->Next(12)];
			plate += (100 + rnd->Next(900)).ToString();
			plate += letters[rnd->Next(12)];
			plate += letters[rnd->Next(12)];

			int mileage = (int)nudMileage->Value * 1000;
			if (mileage == 0) mileage = (5 + rnd->Next(295)) * 1000;
			double speed = 120.0 + rnd->Next(60);

			Car^ car = gcnew Car(plate, palette[rnd->Next(palette->Length)], mileage, speed, SpawnX);

			car->ArrivedAtStand += gcnew CarStandHandler(this, &Form1::OnCarArrived);
			car->ArrivedAtStand += gcnew CarStandHandler(inspector, &Inspector::OnCarArrived);
			car->InspectionFinished += gcnew CarResultHandler(this, &Form1::OnInspectionFinished);
			car->LeftStation += gcnew CarHandler(this, &Form1::OnCarLeft);

			car->GoToStand(stands[0]->X, 0);
			cars->Add(car);
			Log(String::Format(L"Автомобиль {0} (пробег {1} км) въехал на станцию", car->Number, car->Mileage));
		}

		void Log(String^ text) {
			lstLog->Items->Insert(0, String::Format(L"[{0:F1} с] {1}", simTime, text));
			if (lstLog->Items->Count > 300) lstLog->Items->RemoveAt(300);
		}

		void UpdateStats() {
			String^ t = String::Format(L"Проверено: {0}   Годны: {1}   Не прошли: {2}",
				inspector->ProcessedCount, inspector->PassedCount, inspector->FailedCount);
			t += String::Format(L"   На станции: {0}   Ожидают въезда: {1}", cars->Count, pending);
			lblStats->Text = t;
		}

		void OnCarArrived(Car^ car, int standIndex) {
			Log(String::Format(L"Автомобиль {0} прибыл к стенду «{1}»", car->Number, stands[standIndex]->Name));
		}

		void OnCheckStarted(Stand^ stand, Car^ car) {
			Log(String::Format(L"Стенд «{0}»: начата проверка {1}", stand->Name, car->Number));
		}

		void OnCheckCompleted(Stand^ stand, Car^ car, bool passed) {
			String^ res;
			if (passed) res = L"годен";
			else res = L"ОБНАРУЖЕНА НЕИСПРАВНОСТЬ";
			Log(String::Format(L"Стенд «{0}»: {1} — {2}", stand->Name, car->Number, res));
		}

		void OnInspectionFinished(Car^ car, bool passed) {
			String^ res;
			if (passed) res = L"техосмотр пройден, талон выдан";
			else res = L"техосмотр НЕ пройден, талон не выдан";
			Log(String::Format(L"Инспектор {0}: {1} — {2}", inspector->Name, car->Number, res));
		}

		void OnCarLeft(Car^ car) {
			toRemove->Add(car);
			Log(String::Format(L"Автомобиль {0} покинул станцию", car->Number));
		}

		void OnStatsChanged(Object^ sender, EventArgs^ e) {
			UpdateStats();
		}

		void OnAddClick(Object^ sender, EventArgs^ e) {
			if (pending < 10) pending++;
		}

		void OnPauseClick(Object^ sender, EventArgs^ e) {
			timer->Enabled = !timer->Enabled;
			btnPause->Text = timer->Enabled ? L"Пауза" : L"Продолжить";
		}

		void OnSpeedChanged(Object^ sender, EventArgs^ e) {
			lblSpd->Text = String::Format(L"Скорость моделирования: ×{0:F1}", trkSpeed->Value * 0.5);
		}

		void OnFailChanged(Object^ sender, EventArgs^ e) {
			array<double>^ values = gcnew array<double>{ 0.05, 0.10, 0.20, 0.35 };
			double v = values[cmbFail->SelectedIndex];
			if (stands == nullptr) return;
			for each (Stand ^ s in stands) s->FailChance = v;
			Log(String::Format(L"Вероятность брака на стендах изменена: {0:P0}", v));
		}

		void OnTick(Object^ sender, EventArgs^ e) {
			double dt = 0.03 * trkSpeed->Value * 0.5;
			simTime += dt;

			if (chkAuto->Checked) {
				autoTimer += dt;
				if (autoTimer >= 4.0) {
					autoTimer = 0;
					if (pending < 5) pending++;
				}
			}

			if (pending > 0) {
				bool free = cars->Count == 0 ||
					cars[cars->Count - 1]->X >= SpawnX + CarLength + Gap + 2;
				if (free) { pending--; SpawnCar(); }
			}

			for (int i = 0; i < cars->Count; i++) {
				double limit = (i == 0) ? 1.0e9 : cars[i - 1]->X - CarLength - Gap;
				cars[i]->Move(dt, limit);
			}
			for each (Car ^ c in toRemove) cars->Remove(c);
			toRemove->Clear();

			for each (Stand ^ s in stands) s->Update(dt);

			UpdateStats();
			scene->Invalidate();
		}

		void Txt(Graphics^ g, String^ text, System::Drawing::Font^ f, Brush^ b, int cx, int y, int w, int h) {
			g->DrawString(text, f, b, RectangleF((float)(cx - w / 2), (float)y, (float)w, (float)h), fmtCenter);
		}

		void OnScenePaint(Object^ sender, PaintEventArgs^ e) {
			Graphics^ g = e->Graphics;
			g->SmoothingMode = SmoothingMode::AntiAlias;
			g->Clear(Color::FromArgb(226, 233, 241));
			g->DrawString(L"Станция технического осмотра", fontTitle, Brushes::DimGray, 10.0f, 6.0f);

			g->FillRectangle(Brushes::DimGray, 0, 303, scene->Width, 50);
			Pen dash(Color::White, 2.0f);
			dash.DashStyle = DashStyle::Dash;
			g->DrawLine(% dash, 0, 328, scene->Width, 328);

			for each (Stand ^ s in stands) DrawStand(g, s);
			for each (Car ^ c in cars) DrawCar(g, c);

			g->DrawString(L"Въезд ►", fontSmall, Brushes::DimGray, 8.0f, 385.0f);
			g->DrawString(L"Выезд ►", fontSmall, Brushes::DimGray, (float)(scene->Width - 70), 385.0f);
		}

		void DrawStand(Graphics^ g, Stand^ s) {
			int cx = (int)s->X;

			g->FillRectangle(Brushes::Gold, cx - 60, 303, 120, 50);

			Rectangle box = Rectangle(cx - 75, 30, 150, 170);
			Color fill;
			if (s->IsBusy) fill = Color::FromArgb(255, 228, 170);
			else fill = Color::FromArgb(205, 235, 205);
			SolidBrush bFill(fill);
			g->FillRectangle(% bFill, box);
			g->DrawRectangle(Pens::DimGray, box);

			Txt(g, s->Name, fontBold, Brushes::Black, cx, 36, 146, 36);

			String^ st;
			if (s->IsBusy) st = String::Format(L"Проверка: {0}", s->CurrentCar->Number);
			else st = L"Свободен";
			Txt(g, st, fontSmall, Brushes::Black, cx, 78, 146, 20);

			g->FillRectangle(Brushes::LightGray, cx - 60, 112, 120, 14);
			g->FillRectangle(Brushes::SteelBlue, cx - 60, 112, (int)(120 * s->Progress), 14);
			g->DrawRectangle(Pens::Gray, cx - 60, 112, 120, 14);

			Txt(g, String::Format(L"Проверено: {0}", s->ChecksDone), fontSmall, Brushes::Black, cx, 134, 146, 18);
			Txt(g, String::Format(L"Вероятность брака: {0:P0}", s->FailChance), fontSmall, Brushes::Black, cx, 154, 146, 18);

			g->FillRectangle(Brushes::DimGray, cx - 6, 200, 12, 32);
			if (s->IsBusy) g->FillEllipse(Brushes::Red, cx - 9, 230, 18, 12);
			else g->FillEllipse(Brushes::LimeGreen, cx - 9, 230, 18, 12);
		}

		void DrawCar(Graphics^ g, Car^ c) {
			int cx = (int)c->X;
			SolidBrush bBody(c->BodyColor);

			array<Point>^ cab = gcnew array<Point>{
				Point(cx - 30, 262), Point(cx - 18, 242), Point(cx + 18, 242), Point(cx + 32, 262) };
			g->FillPolygon(% bBody, cab);
			g->DrawPolygon(Pens::Black, cab);

			array<Point>^ w1 = gcnew array<Point>{
				Point(cx - 24, 260), Point(cx - 15, 246), Point(cx - 2, 246), Point(cx - 2, 260) };
			array<Point>^ w2 = gcnew array<Point>{
				Point(cx + 2, 260), Point(cx + 2, 246), Point(cx + 16, 246), Point(cx + 26, 260) };
			g->FillPolygon(Brushes::LightSkyBlue, w1);
			g->FillPolygon(Brushes::LightSkyBlue, w2);

			g->FillRectangle(% bBody, cx - 50, 262, 100, 28);
			g->DrawRectangle(Pens::Black, cx - 50, 262, 100, 28);

			g->FillEllipse(Brushes::Black, cx - 38, 283, 22, 22);
			g->FillEllipse(Brushes::Black, cx + 16, 283, 22, 22);
			g->FillEllipse(Brushes::Silver, cx - 31, 290, 8, 8);
			g->FillEllipse(Brushes::Silver, cx + 23, 290, 8, 8);

			g->FillRectangle(Brushes::White, cx - 42, 309, 84, 16);
			Txt(g, c->Number, fontSmall, Brushes::Black, cx, 309, 84, 16);

			if (c->State == CarState::Passed) {
				SolidBrush ok(Color::ForestGreen);
				Txt(g, L"ТО пройден", fontBold, % ok, cx, 356, 140, 18);
			}
			else if (c->State == CarState::Failed) {
				SolidBrush bad(Color::Firebrick);
				Txt(g, L"ТО не пройден", fontBold, % bad, cx, 356, 140, 18);
			}
		}
	};
}